var commodity_app = angular.module('commodityListApp', []);

commodity_app.controller('commodityListController', function($scope, $http){

    //to be completed

});

