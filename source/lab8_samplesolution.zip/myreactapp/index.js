import React from 'react';
import ReactDOM from 'react-dom';
import CommodityPage from './App';

ReactDOM.render(
  <CommodityPage/>,
  document.getElementById('root')
);

