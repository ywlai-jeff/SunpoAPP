var express = require('express'); 
var router = express.Router();

/*
* GET CommodityList.
*/
router.get('/commodities', function(req, res) { 
	var db = req.db;
	var collection = db.get('commodities'); collection.find({},{},function(err,docs){
		res.set({
			"Access-Control-Allow-Origin": "http://localhost:3000"
		});
		
		if (err === null)
			res.json(docs);
		else res.send({msg: err });
	}); 
});
 
/*
* POST to add commodity
*/
router.post('/addcommodity', function (req, res) {
  var db = req.db;
  var collection = db.get('commodities');
 
  res.set({
	"Access-Control-Allow-Origin": "http://localhost:3000",
  });
  
  
  //insert new commodity document
  collection.insert(req.body, function (err, result) {
	      res.send(
            (err === null) ? { msg: '' } : { msg: err }
          );
  });
});

/*
* DELETE to delete a commodity.
*/
router.delete('/deletecommodity/:id', function (req, res) {
  var db = req.db;
  var collection = db.get('commodities');
  var commodityToDelete = req.params.id;
  
  collection.remove({'_id': commodityToDelete}, function (err, result) {
    res.send(
      (err === null) ? { msg: '' } : { msg: err }
    );
  });
});

/*
* PUT to update a commodity (status)
*/
router.put('/updatecommodity/:id', function (req, res) {
  var db = req.db;
  var collection = db.get('commodities');
  var commodityToUpdate = req.params.id;
  
  var filter = { "_id": commodityToUpdate};
  collection.update(filter, { $set: {"status": req.body.status}}, function (err, result) {
	  res.send(
	    (err === null) ? { msg: '' } : { msg: err }
	  );
  })  
});

module.exports = router;
